# Index of linked list

* [Remove](remove.py)
* [Pair Swap](pair_swap.py)
* [Reverse](reverse.py)
* [Linked List](linked_list.py)
* [Cycle Detection](cycle_detection.py)
* [Remove nth Node from End](remove_nth_node_from_end.py)
* [Odd-Even Arrangement](odd_even_arrangement.py)
* [Merge Linked List](merge_linked_list.py)
* [Remove Duplicates](remove_duplicates.py)
* [Delete Last Occurrence](delete_last_occurrence.py)
