# Index of stack

* [Valid Parentheses](valid_parenthesis.py)
* [Largest Rectangle Area in a Histogram](largest_rectangle_area_in_histogram.py)
* [Remove Duplicates Adjacent](remove_duplicates_adjacent.py)
* [Validate Stack Sequence](validate_stack_sequence.py)
