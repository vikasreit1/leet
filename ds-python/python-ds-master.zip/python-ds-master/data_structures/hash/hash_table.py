"""
Create a hash table from scratch. Use chaining for hash collision
"""

class HashTable:


    def __init__(self):
        self.hash_table = 


    def check_collision(self):
        pass


    def add_to_linked_list(self):
        pass


    def insert(self):
        pass


    def delete(self):
        pass


    def get(self):
        pass
