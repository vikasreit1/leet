# Index of strings

* [Check Permutations](check_permutations.py)
* [Are Anagrams](are_anagrams.py)
* [Adjacent Vowel Pairs](adjacent_vowel_pairs.py)
* [Toggle String](toggle_string.py)
* [Is Rotate String](rotate_string.py)
