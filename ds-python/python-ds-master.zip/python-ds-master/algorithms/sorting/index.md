# Index of sorting

* [Insertion Sort](insertion_sort.py)
* [Merge Sort](merge_sort.py)
* [Quick Sort](qsort.py)
* [Select Sort](select_sort.py)
* [Bubble Sort](bubble_sort.py)