# Index of miscellaneous

* [Luhn Algorithm](luhn_algorithm.py)