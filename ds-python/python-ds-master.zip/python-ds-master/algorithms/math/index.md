# Index of math

* [Greatest Common Divisor](greatest_common_divisor.py)
* [Fibonacci Number](fibonacci_number.py)
* [Nth Prime Number](prime.py)
* [Sieve of Erastothenes](sieve_of_eratosthenes.py)
* [Perfect Square](perfect_square.py)
* [Number Convertion](number_convertion.py)
* [Iterative Factorial](factorial_iterative.py)
* [Recursive Factorial](factorial_recursive.py)
