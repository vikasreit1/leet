# Miscellaneous

This is a list of misc links that may be useful when learning or researching data structures and algorithms.

## Links:

- https://google.github.io/eng-practices/review/reviewer/

- https://www.preining.info

- https://cheatsheetseries.owasp.org

- https://wsvincent.com/

- https://machinelearningmastery.com

- https://stackoverflow.com/questions/10631326/difference-between-select-into-and-insert-into-from-old-table

- Why SSL are not issued for IP address - https://stackoverflow.com/a/33419662/6111200

- PATCH vs PUT https://stackoverflow.com/questions/28459418/use-of-put-vs-patch-methods-in-rest-api-real-life-scenarios/39338329#39338329
