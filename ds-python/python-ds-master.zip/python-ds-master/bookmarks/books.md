# Books

This is a list of links to books that may be useful for algorithms and data structures learning.

## Links:

- https://drive.google.com/open?id=1d23_sJdK8XPBJEi-4oUrMnrYMhU2fDcI

- https://drive.google.com/open?id=1sBSGJ8gUakcn0NuQam4BRhRCQfsTrrwh

