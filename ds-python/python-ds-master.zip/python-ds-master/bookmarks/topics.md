# Topics

This is a list of links to topics that may be helpful in learning or researching data structures and algorithms.

## Links:

- https://en.wikipedia.org/wiki/Data_deduplication

- https://searchstorage.techtarget.com/definition/data-deduplication

- https://docs.gitlab.com/ce/development/architecture.html

- https://stackoverflow.com/questions/35390533/actual-difference-between-data-compression-and-data-deduplication

- https://stackoverflow.com/questions/40200413/sessions-vs-token-based-authentication

- https://stackoverflow.com/questions/15678406/when-to-use-myisam-and-innodb

- https://www.bigocheatsheet.com/
