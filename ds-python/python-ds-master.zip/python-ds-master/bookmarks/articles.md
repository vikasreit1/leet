# Articles

This is a list of articles that may be useful for algorithms and data structures learning.

## Links:

- https://www.topcoder.com/community/competitive-programming/tutorials/dynamic-programming-from-novice-to-advanced/

- https://www.hackerearth.com/practice/notes/getting-started-with-the-sport-of-programming/

- https://github.com/alex/what-happens-when

- https://medium.com/@maneesha.wijesinghe1/what-happens-when-you-type-an-url-in-the-browser-and-press-enter-bb0aa2449c1a

- https://blog.sucuri.net/2018/10/owasp-top-10-security-risks-part-i.html

- https://www.cloudflare.com/learning/dns/what-is-dns/

- https://www.keycdn.com/blog/difference-between-http-and-https

- https://www.jeskell.com/blog/jeskell-overview-of-data-deduplication-compression-stumped-by-dedup

- https://forge.medium.com/youre-not-lazy-bored-or-unmotivated-35891b1f3376

- https://github.blog/2009-10-20-how-we-made-github-fast/

- https://www.nextplatform.com/2015/09/24/inside-the-github-systems-where-open-source-lives/

- http://matt.might.net/articles/what-cs-majors-should-know/

- http://cryto.net/~joepie91/blog/2016/06/13/stop-using-jwt-for-sessions/

- http://cryto.net/~joepie91/blog/2016/06/19/stop-using-jwt-for-sessions-part-2-why-your-solution-doesnt-work/

- https://simplystatistics.org/post/

- https://www.analyticsvidhya.com/blog/2016/07/10-analytics-data-science-top-universities-masters-usa/

- https://www.welcometothejungle.co/en/collections/behind-the-code

- https://medium.com/@DoorDash/tips-for-building-high-quality-django-apps-at-scale-a5a25917b2b5

- https://hacktoberfestswaglist.com/#least-involvement-to-most-involvement

- https://www.quora.com/How-is-VPN-different-from-proxy

- https://skerritt.blog/dynamic-programming/

- https://cs.nyu.edu/courses/fall17/CSCI-UA.0102-001/Notes/LinearSort.html

- https://martinfowler.com/articles/serverless.html

- https://samnewman.io/patterns/architectural/bff/

- https://www.ultravioletsoftware.com/single-post/2017/03/23/An-introduction-into-the-WSGI-ecosystem

- https://jwt.io/introduction/

- https://khashtamov.com/en/how-to-become-a-data-engineer/

- https://blog.mirrorfly.com/xmpp-vs-websockets-instant-messaging-protocol-comparison/
