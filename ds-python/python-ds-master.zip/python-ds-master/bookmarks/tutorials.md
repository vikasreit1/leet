# Tutorials

This is a list of links to tutorials that may be helpful in learning or researching data structures and algorithms.

## Links:

- https://cstack.github.io/db_tutorial/

- https://github.com/eon01/kubernetes-workshop

- http://cp-algorithms.com/ 

- https://realpython.com/python-data-classes/

- https://chrisalbon.com
