###69 Sqrt(x)
Implement int sqrt(int x).
Compute and return the square root of x.Implement int sqrt(int x).Compute and return the square root of x.Subscribe to see which companies asked this question
###Solution
```java
public class Solution {
    public int mySqrt(int x) {
        
        
        return (int)Math.sqrt(x);
        
    }
}