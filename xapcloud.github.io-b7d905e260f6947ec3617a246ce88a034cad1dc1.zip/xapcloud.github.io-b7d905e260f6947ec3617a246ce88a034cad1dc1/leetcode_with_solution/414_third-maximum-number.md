###414 Third Maximum Number
Given a non-empty array of integers, return the third maximum number in this array. If it does not exist, return the maximum number. The time complexity must be in O(n).
Example 1:

Input: [3, 2, 1]

Output: 1

Explanation: The third maximum is 1.


Example 2:

Input: [1, 2]

Output: 2

Explanation: The third maximum does not exist, so the maximum (2) is returned instead.


Example 3:

Input: [2, 2, 3, 1]

Output: 1

Explanation: Note that the third maximum here means the third maximum distinct number.
Both numbers with value 2 are both considered as second maximum.

Given a non-empty array of integers, return the third maximum number in this array. If it does not exist, return the maximum number. The time complexity must be in O(n).Example 1:

Input: [3, 2, 1]

Output: 1

Explanation: The third maximum is 1.


Input: [3, 2, 1]

Output: 1

Explanation: The third maximum is 1.
Example 2:

Input: [1, 2]

Output: 2

Explanation: The third maximum does not exist, so the maximum (2) is returned instead.


Input: [1, 2]

Output: 2

Explanation: The third maximum does not exist, so the maximum (2) is returned instead.
Example 3:

Input: [2, 2, 3, 1]

Output: 1

Explanation: Note that the third maximum here means the third maximum distinct number.
Both numbers with value 2 are both considered as second maximum.


Input: [2, 2, 3, 1]

Output: 1

Explanation: Note that the third maximum here means the third maximum distinct number.
Both numbers with value 2 are both considered as second maximum.
Subscribe to see which companies asked this question
###Solution
```java
public class Solution {
    public int thirdMax(int[] nums) {
        
        long a = Long.MIN_VALUE;
        long b = Long.MIN_VALUE;
        long c = Long.MIN_VALUE;
        
        for(int i = 0; i < nums.length; i ++){
            a = Math.max(a,(long)nums[i]);
        }
        for(int i = 0; i < nums.length; i ++){
            if(nums[i]!=a)
                b = Math.max(b,(long)nums[i]);
        }
        for(int i = 0; i < nums.length; i ++){
            if(nums[i]!=a&&nums[i]!=b)
                c = Math.max(c,(long)nums[i]);
        }
        
        return (int)(c==Long.MIN_VALUE?a:c);
        

    }
}