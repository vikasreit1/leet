###274 H-Index

Given an array of citations (each citation is a non-negative integer) of a researcher, write a function to compute the researcher's h-index.


According to the definition of h-index on Wikipedia: "A scientist has index h if h of his/her N papers have at least h citations each, and the other N − h papers have no more than h citations each."


For example, given citations = [3, 0, 6, 1, 5], which means the researcher has 5 papers in total and each of them had received 3, 0, 6, 1, 5 citations respectively. Since the researcher has 3 papers with at least 3 citations each and the remaining two with no more than 3 citations each, his h-index is 3.


Note: If there are several possible values for h, the maximum one is taken as the h-index.


An easy approach is to sort the array first.
What are the possible values of h-index?
A faster approach is to use extra space.

Credits:Special thanks to @jianchao.li.fighter for adding this problem and creating all test cases.
Given an array of citations (each citation is a non-negative integer) of a researcher, write a function to compute the researcher's h-index.

According to the definition of h-index on Wikipedia: "A scientist has index h if h of his/her N papers have at least h citations each, and the other N − h papers have no more than h citations each."

For example, given citations = [3, 0, 6, 1, 5], which means the researcher has 5 papers in total and each of them had received 3, 0, 6, 1, 5 citations respectively. Since the researcher has 3 papers with at least 3 citations each and the remaining two with no more than 3 citations each, his h-index is 3.

Note: If there are several possible values for h, the maximum one is taken as the h-index.
Credits:Special thanks to @jianchao.li.fighter for adding this problem and creating all test cases.Subscribe to see which companies asked this question
###Solution
```java
public class Solution {
    public int hIndex(int[] citations) {
        if(citations.length == 0)
            return 0;
        
        int max = 0;
        
        int len = citations.length;
        
        for(int i = 0; i <= len ; i ++){
            int count = 0;
            for(int j = 0; j < len; j++){
                if(citations[j]>=i)
                    count++;
            }
            
            if(count >= i)
                max = Math.max(i,max);
        }
        
        
        return max;
    }
}