###50 Pow(x, n)
Implement pow(x, n).
Implement pow(x, n).
Subscribe to see which companies asked this question
###Solution
```java
public class Solution {
    public double myPow(double x, int n) {
        return Math.pow(x,n);
    }
}